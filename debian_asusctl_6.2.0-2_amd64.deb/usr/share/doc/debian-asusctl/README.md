# debian_asusctl (v6.2.0-debian2)

Native Debian / Kali GNU/Linux hardware power performance and custom keyboard button controller for ASUS laptops (including ZenBook Pro Duo UX582LR, ZenBook, VivoBook, TUF, and ROG).

## Quick Commands
- `asusctl status` — Full hardware, power profile, CPU governor/RAPL TDP, fan RPM, keyboard LED, ScreenPad Plus & battery status
- `asusctl profile -l` — List available power profiles (`Quiet`, `Balanced`, `Performance`, `FullSpeed`)
- `asusctl profile -P Performance` — Switch to Performance mode (or `Quiet`, `Balanced`, `FullSpeed`)
- `asusctl profile -n` — Cycle to the next power profile
- `asusctl fan fullspeed` / `asusctl fan auto` — Toggle maximum fan boost vs automatic thermal fan curve
- `asusctl -k high` / `asusctl -n` / `asusctl -p` — Control keyboard backlight brightness (`0..3`)
- `asusctl screenpad toggle` / `asusctl screenpad brightness 200` — Control ASUS ScreenPad Plus secondary display
- `asusctl -c 80` — Limit battery charge ceiling to 80% for battery longevity
- `asusctl keys list` — View all 10 custom ASUS hardware keyboard buttons and their actions
- `asusctl keys bind <button> <action>` — Customize any ASUS hardware button (including `exec:<command>`)
